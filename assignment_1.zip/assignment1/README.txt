Anmol Porwal ( 150108 )
CS251 Assignment1 : Bash

I have displayed the outputs at the standard output, I could have also done the same in an output file but it was not specified in the assignment hence. 

